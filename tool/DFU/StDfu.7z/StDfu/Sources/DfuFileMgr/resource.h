//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DfuFileMgr.rc
//
#define IDD_DfuFileMgr_DIALOG           102
#define IDD_DfuFileMgrGenerate_DIALOG   102
#define IDR_MAINFRAME                   128
#define IDD_DfuFileMgrExtract_DIALOG    129
#define IDD_DfuFileMgrMultiBin_DIALOG   130
#define IDD_DfuFileMgrWhatToDo_DIALOG   131
#define IDC_EDITVID                     1000
#define IDC_EDITPID                     1001
#define IDC_EDITVERSION                 1002
#define IDC_EDITFILE                    1003
#define IDC_BUTTONFILE                  1004
#define IDC_EDITALTSET                  1005
#define IDC_BUTTONADD                   1006
#define IDC_BUTTONADDS19HEX             1006
#define IDC_BUTTONDELETE                1007
#define IDC_BUTTONADDBIN                1007
#define IDC_LISTS19                     1008
#define IDC_LISTFILES                   1008
#define IDC_LISTBIN                     1008
#define IDC_BUTTONGENERATE              1009
#define IDC_BUTTONLOAD                  1010
#define IDC_BUTTONDELETEIMAGE           1010
#define IDC_EDITSTARTADDR               1011
#define IDC_BUTTONOPEN                  1011
#define IDC_EDITENDADDR                 1012
#define IDC_BUTTONEXTRACT               1012
#define IDC_RADIOS19                    1013
#define IDC_RADIOHEX                    1014
#define IDC_RADIOCHOICE                 1014
#define IDC_RADIOMULTIBIN               1015
#define IDC_RADIOCHOICE2                1015
#define IDC_EDITTRGTNAME                1015
#define IDC_DFU_FILE                    1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
